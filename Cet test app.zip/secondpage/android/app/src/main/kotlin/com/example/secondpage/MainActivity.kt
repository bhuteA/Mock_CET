package com.example.secondpage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
